This is the README file of the python module s2Dcd.

See the directory "docs" for the documentation and the installation
instructions.



